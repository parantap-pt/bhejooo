<div class="row" style="margin-left:10px; margin-top:20px; margin-right:20px"> 
    <div>
        <span class="pull-right"><a href="javascript:void(0);" class="btn blue btn-toggler"><b><i class="fa fa-long-arrow-left"></i></b> Back</a> </span>
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    </div>
<div>
    &nbsp;
</div>
<br>
<div class="row" style="margin-left:10px;"> 
<div class="col-sm-12">
    <div class="panel panel-primary">
        <div class="panel-heading">
            User Details
        </div>
        <div class="panel-body employee_full_view">
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group row">
                        <label class="col-sm-4 col-form-label"><b>First Name</b> : </label>
                        <div class="col-sm-8">#FIRST_NAME#</div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-4 col-form-label"><b>Last Name</b> : </label>
                        <div class="col-sm-8">#LAST_NAME#</div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-4 col-form-label"><b>Email</b> : </label>
                        <div class="col-sm-8">#EMAIL#</div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-4 col-form-label"><b>Created Date</b> : </label>
                        <div class="col-sm-8">#CREATED_DATE#</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


