<?php
	require_once("../../include/config.php");
	echo disMessage($toastr_message);

?>