<?php
    
    // define("ENVIRONMENT", "d");
    // define("DB_HOST", "localhost");
    // define("DB_USER", "hitchnot_user");
    // define("DB_PASS", "~17^iuJ^#hip");
    // define("DB_NAME", "hitchnot_dating");
    // define("PROJECT_DIRECTORY_NAME", "");
    // define('SITE_URL', 'https://' . $_SERVER["SERVER_NAME"] . '/');
    // define('ADMIN_URL', SITE_URL . 'admin/');
    // define('DIR_URL', $_SERVER["DOCUMENT_ROOT"] . '/');
    // error_reporting(0);
    
   // Local credensials
    
    define("ENVIRONMENT", "d");
    define("DB_HOST", "localhost");
    define("DB_USER", "root");
    define("DB_PASS", "");  
    define("DB_NAME", "digital");
    define("PROJECT_DIRECTORY_NAME", "digital");
    define('SITE_URL', 'http://' . $_SERVER["SERVER_NAME"] . '/digital/');
    define('ADMIN_URL', SITE_URL . 'admin/');
    define('DIR_URL', $_SERVER["DOCUMENT_ROOT"] . '/digital/');
    error_reporting(E_ALL);
    



